import csv
import os

def append_to_csv(data, filename='data.csv'):
    """
    Appends data to a CSV file. If the file doesn't exist, it creates it with headers.
    Data should be a list of values to append as a row.
    """
    file_exists = os.path.isfile(filename)
    with open(filename, 'a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            # Assuming data has 4 fields: age, height, gender, weight
            writer.writerow(['Age', 'Height', 'Gender', 'Weight'])
        writer.writerow(data)